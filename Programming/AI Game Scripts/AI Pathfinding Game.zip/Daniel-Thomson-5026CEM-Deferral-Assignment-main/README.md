# Daniel-Thomson-5026CEM-Deferral-Assignment

This github will include a video showcasing the AI in action along with the code provided to make it work.
There will also be a report based on the AI implemented in the project.

Controls for the Player:

Movement:
W - Up
A - Left
S - Down
D - Right

Objective: Get to the Green square without getting hit by the enemies.

